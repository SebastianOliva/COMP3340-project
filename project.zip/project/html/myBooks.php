<html>
    <head>
        <title>My Books</title>
        <link rel="icon" type="image/png" href="../pictures/favicon.ico"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../css/table.css">
        <script src="../js/checkboxes.js"></script>
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <script src="../js/jquery-3.5.1.slim.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="container">
        <!-- TOP NAVIGATION -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <a class="navbar-brand unselectable">University of Windsor Library</a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
              <a class="nav-item nav-link" href="bookSearch.php">Book Search<span class="sr-only">(current)</span></a>
              <a class="nav-item nav-link active" href="myBooks.php">My Books</a>
              <a class="nav-item nav-link" href="profile.php">Profile</a>
              <a class="nav-item nav-link" href="signOut.php">Sign out</a>
            </div>
          </div>
        </nav>
        <!-- TOP NAVIGATION -->
        
        <br/>
        <h1 class="unselectable">My Books</h1>
        <br/>
        <?php
            // CONNECT TO DB ----------------------------
            require_once 'login.php';
            $conn = new mysqli($hn, $un, $pw, $db);
            if ($conn->connect_error)
                die($conn->connect_error);
            // ------------------------------------------
            
            // CHECK SESSION -----------------------------------------------------------------------------------
            session_start();
            if (!isset($_SESSION['username']) || !isset($_SESSION['timeout']) || $_SESSION['timeout'] < time() || ($_SESSION['clientTypeID'] != 1 && $_SESSION['clientTypeID'] != 2))
            {
                session_unset();
                header("Location: index.php");
                
            }
            else
            {
                $_SESSION['timeout'] = time() + 60 * 30;
                $username = $_SESSION['username'];
            }
            // -------------------------------------------------------------------------------------------------

            // Cancel book reservation ----------------------------------------
            if (isset($_POST['cancelReservation']))
            {
                $isbn = $_POST['cancelReservation'];
                $query  =  "DELETE FROM
                            	BookLending
                            WHERE
                            	ISBN = $isbn AND
                                UniversityID = '$username' AND
                                IsReservation = 1";
                $result = $conn->query($query);
                if (!$result)
                  die ("Database access failed: " . $conn->error);
                echo "Reservation cancelled.<br><br><hr class='my-4'><br><br>";
                
            }


        // get My Books from DB ------------------------------
            $query  = "SELECT
                    	b.Title,
                        a.Author,
                        bl.ISBN,
                        c.Category,
                        CASE
                        	WHEN bl.DateLent IS NULL THEN 'N/A'
                            ELSE bl.DateLent
                        END,
                        CASE
                        	WHEN bl.DateDue IS NULL THEN 'N/A'
                            ELSE bl.DateDue
                        END,
                        CASE
                        	WHEN bl.IsReservation = 1 THEN 'Reserved'
                            WHEN bl.IsReservation = 0 THEN 'Lent'
                            ELSE ''
                        END
                    FROM
                    	BookLending bl
                        LEFT JOIN Books b on bl.ISBN = b.ISBN
                        LEFT JOIN Authors a on b.AuthorID = a.AuthorID
                        LEFT JOIN Category c ON b.CategoryID = c.CategoryID
                    WHERE
                    	UniversityID = '$username';";
            $result = $conn->query($query);
            if (!$result)
                die ("Database access failed: " . $conn->error);
             $rows = $result->num_rows;
        // -------------------------------------------------------
        
        // print table of books -------------------------------
            echo <<<_END
                <form method ="post" action="myBooks.php">
                <div class="table-responsive">
                    <table>
                    <thead>
                          <tr>
                            <th>Title</th>
                            <th>Author</th>
                            <th>ISBN</th>
                            <th>Category</th>
                            <th>Date Lent</th>
                            <th>Date Due</th>
                            <th>Status</th>
                            <th></th>
                          </tr>
                    </thead>
_END;

            if ($rows > 0)
            {
                for ($j = 0 ; $j < $rows ; ++$j)
                {
                    $result->data_seek($j);
                    $row = $result->fetch_array(MYSQLI_NUM);
            
                    echo <<<_END
                          <tr>
                            <td class="titleColumn">$row[0]</td>
                            <td>$row[1]</td>
                            <td>$row[2]</td>
                            <td>$row[3]</td>
                            <td>$row[4]</td>
                            <td>$row[5]</td>
                            <td>$row[6]</td>
                            <td>
_END;
                    if ($row[6] == 'Reserved')
                        echo "<label for='button'><button type='submit' name='cancelReservation' value='$row[2]' class='btn btn-primary btn-sm'>Cancel</button></label>";
                    echo <<<_END
                            </td>
                          </tr>
_END;
                }
            }
            else
            {
                echo <<<_END
                          <tr>
                            <td colspan="8" style="text-align:center;">You have no lent or reserved books</td>
                          </tr>
_END;
            }

            echo <<<_END
            </table>
            </div>
            </form>
_END;
        // -------------------------------------------------------
        
            $result->close();
            $conn->close();
          
            function get_post($conn, $var)
            {
                return $conn->real_escape_string($_POST[$var]);
            }
        ?>
        </div>
    </body>
</html>