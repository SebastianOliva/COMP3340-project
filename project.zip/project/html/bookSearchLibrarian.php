<html>
    <head>
        <title>Book Search</title>
        <link rel="icon" type="image/png" href="../pictures/favicon.ico"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../css/table.css">
        <script src="../js/ajax.js"> </script>
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <script src="../js/jquery-3.5.1.slim.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="container">
        <!----------------- TOP NAVIGATION ------------------------>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <a class="navbar-brand unselectable">University of Windsor Library</a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
              <a class="nav-item nav-link active" href="bookSearchLibrarian.php">Book Search<span class="sr-only">(current)</span></a>
              <a class="nav-item nav-link" href="lentBooks.php">Lent Books</a>
              <a class="nav-item nav-link" href="addBooks.php">Add Book</a>
              <a class="nav-item nav-link" href="reports.php">Reports</a>
              <a class="nav-item nav-link" href="signOut.php">Sign Out</a>
            </div>
          </div>
        </nav>
        <!----------------- TOP NAVIGATION ----------------------->
        
        <br/>
        <h1 class="unselectable">Book Search</h1>
        <br/>
        <?php
            // CONNECT TO DB ----------------------------
            require_once 'login.php';
            $conn = new mysqli($hn, $un, $pw, $db);
            if ($conn->connect_error)
                die($conn->connect_error);
            // ------------------------------------------
            
            // CHECK SESSION -----------------------------------------------------------------------------------
            session_start();
            if (!isset($_SESSION['username']) || !isset($_SESSION['timeout']) || $_SESSION['timeout'] < time() || $_SESSION['clientTypeID'] != 3)
            {
                session_unset();
                header("Location: index.php");
            }
            else
            {
                $_SESSION['timeout'] = time() + 60 * 30;
                $username = $_SESSION['username'];
            }
            // -------------------------------------------------------------------------------------------------

            // LEND OUT BOOK --------------------------------------
            if (isset($_POST['isbn']) && isset($_POST['clientID']))
            {
                $isbn = $_POST['isbn'];
                
                $clientID = get_post($conn, 'clientID');

                $fail = false;
                
                // check for client existing
                $query  =  "SELECT
                            	COUNT(*)
                            FROM
                            	Client
                            WHERE
                            	Client.UniversityID = '$clientID' AND Client.ClientTypeID != 3";
                $result = $conn->query($query);
                if (!$result)
                  die ("Database access failed: " . $conn->error);
                $result->data_seek(0);
                $row = $result->fetch_array(MYSQLI_NUM);
                if ($row[0] != 1)
                {
                    echo "UWinID does not exist or does not belong to a valid account.<br><br><hr class='my-4'><br><br>";
                    $fail = true;
                }
                if (!$fail)
                {
                    // check for outstanding fees
                    $query  =  "SELECT
                                	OutStandingFees
                                FROM
                                	Client
                                WHERE
                                	Client.UniversityID = '$clientID'";
                    $result = $conn->query($query);
                    if (!$result)
                      die ("Database access failed: " . $conn->error);
                    $result->data_seek(0);
                    $row = $result->fetch_array(MYSQLI_NUM);
                    if ($row[0] > 0)
                    {
                        echo "Client cannot reserve a book because they have outstanding fees on your account.<br><br><hr class='my-4'><br><br>";
                        $fail = true;
                    }
                    
                    // check for too many books
                    $query  =  "SELECT
                                	COUNT(*)
                                FROM
                                    BookLending
                                WHERE
                                	UniversityID = '$clientID'";
                    $result = $conn->query($query);
                    if (!$result)
                      die ("Database access failed: " . $conn->error);
                    $result->data_seek(0);
                    $row = $result->fetch_array(MYSQLI_NUM);
                    if ($row[0] >= 2)
                    {
                        echo "Client cannot reserve or lend more than two books at once.<br><br><hr class='my-4'><br><br>";
                        $fail = true;
                    }
                    
                    // check out more than one of the same book
                    $query  =  "SELECT
                                    COUNT(*)
                                FROM
                                	BookLending
                                WHERE ISBN = $isbn AND UniversityID = '$clientID'";
                    $result = $conn->query($query);
                    if (!$result)
                      die ("Database access failed: " . $conn->error);
                    $result->data_seek(0);
                    $row = $result->fetch_array(MYSQLI_NUM);
                    if ($row[0] >= 1)
                    {
                        echo "Client cannot reserve or lend more than one of the same book.<br><br><hr class='my-4'><br><br>";
                        $fail = true;
                    }
                    
                    // lend book if no fails
                    if (!$fail)
                    {
                        $query  =  "SELECT
                                    	ClientTypeID
                                    FROM
                                    	Client
                                    WHERE
                                    	Client.UniversityID = '$clientID'";
                        $result = $conn->query($query);
                        if (!$result)
                          die ("Database access failed: " . $conn->error);
                        $result->data_seek(0);
                        $row = $result->fetch_array(MYSQLI_NUM);
                        
                        if ($row[0] == 1)
                            $query  = "INSERT INTO BookLending (ISBN, IsReservation, UniversityID, DateLent, DateDue) VALUES ($isbn, 0, '$clientID', CURDATE(), DATE_ADD(CURDATE(), INTERVAL 1 MONTH))";
                        else if ($row[0] == 2)
                            $query  = "INSERT INTO BookLending (ISBN, IsReservation, UniversityID, DateLent, DateDue) VALUES ($isbn, 0, '$clientID', CURDATE(), DATE_ADD(CURDATE(), INTERVAL 4 MONTH))";
                        
                        $result = $conn->query($query);
                        if (!$result)
                          die ("Database access failed: " . $conn->error);
                        echo "Book successfully lent.<br><br><hr class='my-4'><br><br>";
                    }
                }
            }
            // ---------------------------------------------------

            // get all books from DB ------------------------------
            $query  =  "SELECT
                        	b.Title,
                            a.Author,
                            b.ISBN,
                            c.Category,
                            concat(b.StockQuantity - (CASE WHEN bl.Unavailable IS NULL THEN 0 ELSE bl.Unavailable END), '/', b.StockQuantity) AS Stock,
                            b.StockQuantity - (CASE WHEN bl.Unavailable IS NULL THEN 0 ELSE bl.Unavailable END) As Available,
                            p.Publisher
                        FROM
                        	Books b
                            LEFT JOIN Authors a ON b.AuthorID = a.AuthorID
                            LEFT JOIN Category c ON b.CategoryID = c.CategoryID
                            LEFT JOIN (SELECT
                                       		ISBN,
                                       		COUNT(*) as Unavailable
                                       FROM
                                       		BookLending
                                       GROUP BY ISBN) bl ON b.ISBN = bl.ISBN
                            LEFT JOIN Publishers p on b.PublisherID = p.PublisherID
                        ORDER BY
                        	b.Title";
            $result = $conn->query($query);
            if (!$result)
              die ("Database access failed: " . $conn->error);
            $rows = $result->num_rows;
            // -------------------------------------------------------
        
            // print table of books -------------------------------
            echo <<<_END
            
                <form name='ajax' onsubmit='return false;'>
                    <div class="md-form mt-0">
                        Search Title: <input name='title' class='form-control' id='title' type='text' onkeyup='searchTitleLibrarian();'>
                    </div>
                </form>
                
                <form method ="post" action="bookSearchLibrarian.php">
                    <div class="md-form mt-0">
                        Client UWinID: <input class='form-control' type="text" id="clientID" name="clientID" required>
                    </div>
                    <br>
                    <div class="table-responsive" id="searchBooksTable">
                        <table>
                            <thead>
                                  <tr>
                                    <th>Title</th>
                                    <th>Author</th>
                                    <th>ISBN</th>
                                    <th>Category</th>
                                    <th>Publisher</th>
                                    <th>Stock</th>
                                    <th></th>
                                  </tr>
                            </thead>
_END;

          for ($j = 0 ; $j < $rows ; ++$j)
          {
            $result->data_seek($j);
            $row = $result->fetch_array(MYSQLI_NUM);
        
            echo <<<_END
                            <tr>
                                <td class="titleColumn">$row[0]</td>
                                <td>$row[1]</td>
                                <td>$row[2]</td>
                                <td>$row[3]</td>
                                <td>$row[6]</td>
                                <td>$row[4]</td>
                                <td>
                                    <label for="button">
_END;
            if ($row[5] > 0) // check for book in stock
                echo "<button type='submit' name='isbn' value='$row[2]' class='btn btn-primary btn-sm'>Lend</button>";
            else
                echo "<button class='btn btn-secondary btn-sm' disabled>Lend</button>";
            echo <<<_END
                                    </label>
                                </td>
                            </tr>
_END;
            }
            echo <<<_END
                        </table>
                    </div>
                </form>
_END;
        // -------------------------------------------------------
        
          $result->close();
          $conn->close();

          function get_post($conn, $var)
          {
            return $conn->real_escape_string($_POST[$var]);
          }
        ?>

    </div>
    </body>
</html>