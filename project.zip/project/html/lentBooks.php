<html>
    <head>
        <title>Lent Books</title>
        <link rel="icon" type="image/png" href="../pictures/favicon.ico"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../css/table.css">
        <script src="../js/ajax.js"> </script>
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <script src="../js/jquery-3.5.1.slim.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="container">
        <!----------------- TOP NAVIGATION ------------------------>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <a class="navbar-brand unselectable">University of Windsor Library</a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
              <a class="nav-item nav-link" href="bookSearchLibrarian.php">Book Search</a>
              <a class="nav-item nav-link active" href="lentBooks.php">Lent Books<span class="sr-only">(current)</span></a>
              <a class="nav-item nav-link" href="addBooks.php">Add Book</a>
              <a class="nav-item nav-link" href="reports.php">Reports</a>
              <a class="nav-item nav-link" href="signOut.php">Sign Out</a>
            </div>
          </div>
        </nav>
        <!----------------- TOP NAVIGATION ----------------------->
        
        <br/>
        <h1 class="unselectable">Lent Books</h1>
        <br/>
        <?php
            // CONNECT TO DB ----------------------------
            require_once 'login.php';
            $conn = new mysqli($hn, $un, $pw, $db);
            if ($conn->connect_error)
                die($conn->connect_error);
            // ------------------------------------------
            
            // CHECK SESSION -----------------------------------------------------------------------------------
            session_start();
            if (!isset($_SESSION['username']) || !isset($_SESSION['timeout']) || $_SESSION['timeout'] < time() || $_SESSION['clientTypeID'] != 3)
            {
                session_unset();
                header("Location: index.php");
            }
            else
            {
                $_SESSION['timeout'] = time() + 60 * 30;
                $username = $_SESSION['username'];
            }
            // -------------------------------------------------------------------------------------------------
            
            // Cancel book reservation ----------------------------------------
            if (isset($_POST['cancelReservation']))
            {
                $lendID = $_POST['cancelReservation'];
                $query  =  "INSERT FROM
                            	BookLending
                            WHERE
                            	LendID = $lendID";
                $result = $conn->query($query);
                if (!$result)
                  die ("Database access failed: " . $conn->error);
                echo "Reservation cancelled.<br><br><hr class='my-4'><br><br>";
                
            }
            // ----------------------------------------------------------------

            // Return book ----------------------------------------------------
            if (isset($_POST['returnBook']))
            {
                $lendID = $_POST['returnBook'];
                $query  =  "INSERT INTO
                            	LendingArchive (UniversityID, ISBN, DateLent, DateDue, DateReturned)
                            VALUES
                               ((SELECT UniversityID FROM BookLending WHERE LendID = $lendID),
                                (SELECT ISBN FROM BookLending WHERE LendID = $lendID),
                                (SELECT DateLent FROM BookLending WHERE LendID = $lendID),
                                (SELECT DateDue FROM BookLending WHERE LendID = $lendID),
                                CURDATE()); ";
                $query  .=  "DELETE FROM
                            	BookLending
                            WHERE
                            	LendID = $lendID;";
                $conn->multi_query($query);
                if ($result)
                  die ("Database access failed: " . $conn->error);
                  
                do
                {
                    if (0 !== $conn->errno)
                    {
                        echo "Multi query failed: (" . $conn->errno . ") " . $conn->error;
                        break;
                    }
                    if (($conn->more_results()) === false)
                        break;
                    $conn->next_result();
                } while (true);  
                  
                echo "Book returned.<br><br><hr class='my-4'><br><br>";
                
            }
            // ----------------------------------------------------------------

            // get lent books from DB ------------------------------
            $query  =   "SELECT
							bl.UniversityID,
                        	b.Title,
                            a.Author,
                            bl.ISBN,
                            c.Category,
                            CASE
                            	WHEN bl.DateLent IS NULL THEN 'N/A'
                                ELSE bl.DateLent
                            END,
                            CASE
                            	WHEN bl.DateDue IS NULL THEN 'N/A'
                                ELSE bl.DateDue
                            END,
                            CASE
                            	WHEN bl.IsReservation = 1 THEN 'Reserved'
                                WHEN bl.IsReservation = 0 THEN 'Lent'
                                ELSE ''
                            END,
                            bl.LendID
                        FROM
                        	BookLending bl
                            LEFT JOIN Books b on bl.ISBN = b.ISBN
                            LEFT JOIN Authors a on b.AuthorID = a.AuthorID
                            LEFT JOIN Category c ON b.CategoryID = c.CategoryID
                        ORDER BY bl.UniversityID";
            $result = $conn->query($query);
            if (!$result)
                die ("Database access failed: " . $conn->error);
             $rows = $result->num_rows;
        // -------------------------------------------------------
        
        // print table of books -------------------------------
            echo <<<_END
                <form name='ajax' onsubmit='return false;'>
                    <div class="md-form mt-0">
                        Search UWinID: <input name='clientID' class='form-control' id='clientID' type='text' onkeyup='searchClientID();'>
                    </div>
                </form>
                <form method ="post" action="lentBooks.php">
                <div class="table-responsive" id="lentBooksTable">
                    <table>
                    <thead>
                          <tr>
                            <th>UWinID</th>
                            <th>Title</th>
                            <th>Author</th>
                            <th>ISBN</th>
                            <th>Category</th>
                            <th>Date Lent</th>
                            <th>Date Due</th>
                            <th>Status</th>
                            <th></th>
                          </tr>
                    </thead>
_END;

            if ($rows > 0)
            {
                for ($j = 0 ; $j < $rows ; ++$j)
                {
                    $result->data_seek($j);
                    $row = $result->fetch_array(MYSQLI_NUM);
            
                    echo <<<_END
                          <tr>
                            <td>$row[0]</td>
                            <td class="titleColumn">$row[1]</td>
                            <td>$row[2]</td>
                            <td>$row[3]</td>
                            <td>$row[4]</td>
                            <td>$row[5]</td>
                            <td>$row[6]</td>
                            <td>$row[7]</td>
                            <td>
_END;
                    if ($row[7] == 'Reserved')
                        echo "<label for='button'><button type='submit' name='cancelReservation' value='$row[8]' class='btn btn-primary btn-sm'>Cancel</button></label>";
                    else if ($row[7] == 'Lent')
                        echo "<label for='button'><button type='submit' name='returnBook' value='$row[8]' class='btn btn-primary btn-sm'>Return</button></label>";
                    echo <<<_END
                            </td>
                          </tr>
_END;
                }
            }
            else
            {
                echo <<<_END
                          <tr>
                            <td colspan="8" style="text-align:center;">There are no lent or reserved books.</td>
                          </tr>
_END;
            }

            echo <<<_END
            </table>
            </div>
            </form>
_END;
        // -------------------------------------------------------
            
            
            $result->close();
            $conn->close();
    
            function get_post($conn, $var)
            {
                return $conn->real_escape_string($_POST[$var]);
            }
        ?>

    </div>
    </body>
</html>