<html>
    <head>
        <title>Add Books</title>
        <link rel="icon" type="image/png" href="../pictures/favicon.ico"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../css/table.css">
        <script src="../js/ajax.js"> </script>
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <script src="../js/jquery-3.5.1.slim.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="container">
        <!----------------- TOP NAVIGATION ------------------------>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <a class="navbar-brand unselectable">University of Windsor Library</a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
              <a class="nav-item nav-link" href="bookSearchLibrarian.php">Book Search</a>
              <a class="nav-item nav-link" href="lentBooks.php">Lent Books</a>
              <a class="nav-item nav-link active" href="addBooks.php">Add Book<span class="sr-only">(current)</span></a>
              <a class="nav-item nav-link" href="reports.php">Reports</a>
              <a class="nav-item nav-link" href="signOut.php">Sign Out</a>
            </div>
          </div>
        </nav>
        <!----------------- TOP NAVIGATION ----------------------->
        
        <br/>
        <h1 class="unselectable">Add Books</h1>
        <br/>
        <?php
            // CONNECT TO DB ----------------------------
            require_once 'login.php';
            $conn = new mysqli($hn, $un, $pw, $db);
            if ($conn->connect_error)
                die($conn->connect_error);
            // ------------------------------------------
            
            // CHECK SESSION -----------------------------------------------------------------------------------
            session_start();
            if (!isset($_SESSION['username']) || !isset($_SESSION['timeout']) || $_SESSION['timeout'] < time() || $_SESSION['clientTypeID'] != 3)
            {
                session_unset();
                header("Location: index.php");
            }
            else
            {
                $_SESSION['timeout'] = time() + 60 * 30;
                $username = $_SESSION['username'];
            }
            // -------------------------------------------------------------------------------------------------
            
            
            // add new book to DB ----------------------------------------------------
            if (isset($_POST['author'])   &&
                isset($_POST['title'])    &&
                isset($_POST['category']) &&
                isset($_POST['isbn'])     &&
                isset($_POST['publisher'])&&
                isset($_POST['quantity']))
            {
                $fail = false;
                $author   = get_post($conn, 'author');
                $title    = get_post($conn, 'title');
                $category = get_post($conn, 'category');
                $isbn     = get_post($conn, 'isbn');
                $publisher= get_post($conn, 'publisher');
                $quantity = get_post($conn, 'quantity');
                
                // check if ISBN already exists --------------------------------
                $query =   "SELECT
                            	COUNT(*)
                            FROM
                            	Books
                            WHERE
                            	ISBN = $isbn";
                $result = $conn->query($query);
                if (!$result)
                  die ("Database access failed: " . $conn->error);
                $result->data_seek(0);
                $row = $result->fetch_array(MYSQLI_NUM);
                if ($row[0] > 0)
                {
                    echo "ISBN already exists in database.<br><br><hr class='my-4'><br><br>";
                    $fail = true;
                }
                // -------------------------------------------------------------

                if (!$fail)
                {
                    // check if author exists --------------------------------------
                    $query =   "SELECT
                                	AuthorID
                                FROM
                                	Authors
                                WHERE
                                	Author = '$author'";
                    $result = $conn->query($query);
                    if (!$result)
                      die ("Database access failed: " . $conn->error);
                    if(mysqli_num_rows($result) == 0)
                    {
                        $query = "INSERT INTO Authors (Author) VALUES ('$author')";
                        $result = $conn->query($query);
                        if (!$result)
                          die ("Database access failed: " . $conn->error);
                        $query = "SELECT AuthorID FROM Authors WHERE Author='$author'";
                        $result = $conn->query($query);
                        if (!$result)
                          die ("Database access failed: " . $conn->error);
                        echo "New author added.<br><br><hr class='my-4'><br><br>";
                    }
                    $result->data_seek(0);
                    $row = $result->fetch_array(MYSQLI_NUM);
                    $author = $row[0];
                    // ---------------------------------------------------------

                    // check if category exists --------------------------------------
                    $query =   "SELECT
                                	CategoryID
                                FROM
                                	Category
                                WHERE
                                	Category = '$category'";
                    $result = $conn->query($query);
                    if (!$result)
                      die ("Database access failed: " . $conn->error);
                    if(mysqli_num_rows($result) == 0)
                    {
                        $query = "INSERT INTO Category (Category) VALUES ('$category')";
                        $result = $conn->query($query);
                        if (!$result)
                          die ("Database access failed: " . $conn->error);
                        $query = "SELECT CategoryID FROM Category WHERE Category='$category'";
                        $result = $conn->query($query);
                        if (!$result)
                          die ("Database access failed: " . $conn->error);
                        echo "New category added.<br><br><hr class='my-4'><br><br>";
                    }
                    $result->data_seek(0);
                    $row = $result->fetch_array(MYSQLI_NUM);
                    $category = $row[0];
                    // ---------------------------------------------------------
                
                    // check if publisher exists --------------------------------------
                    $query =   "SELECT
                                	PublisherID
                                FROM
                                	Publishers
                                WHERE
                                	Publisher = '$publisher'";
                    $result = $conn->query($query);
                    if (!$result)
                      die ("Database access failed: " . $conn->error);
                    if(mysqli_num_rows($result) == 0)
                    {
                        $query = "INSERT INTO Publishers (Publisher) VALUES ('$publisher')";
                        $result = $conn->query($query);
                        if (!$result)
                          die ("Database access failed: " . $conn->error);
                        $query = "SELECT PublisherID FROM Publishers WHERE Publisher='$publisher'";
                        $result = $conn->query($query);
                        if (!$result)
                          die ("Database access failed: " . $conn->error);
                        echo "New publisher added.<br><br><hr class='my-4'><br><br>";
                    }
                    $result->data_seek(0);
                    $row = $result->fetch_array(MYSQLI_NUM);
                    $publisher = $row[0];
                    // ---------------------------------------------------------
                    
                    // add book --------------------------------------------------
                    $query =   "INSERT INTO
                                	Books (AuthorID, CategoryID, ISBN, PublisherID, StockQuantity, Title)
                                VALUES
                                	($author, $category, $isbn, $publisher, $quantity, '$title')";
                    $result = $conn->query($query);
                    if (!$result)
                        die ("Database access failed: " . $conn->error);
                    echo "Book added successfully.<br><br><hr class='my-4'><br><br>";
                    // -----------------------------------------------------------
                }
                
              	if (!$result)
              	    echo "INSERT failed: $query<br>" . $conn->error . "<br><br>";
            }
          // -----------------------------------------------------------------------
        
            echo <<<_END
              <form action="addBooks.php" method="post">
                  <div class="md-form mt-0">
                        Author <input type="text" class='form-control' name="author" required>
                         Title <input type="text" class='form-control' name="title" required>
                      Category <input type="text" class='form-control' name="category" required>
                          ISBN <input type="number" class='form-control' name="isbn" min="1" and step="1" required>
                     Publisher <input type="text" class='form-control' name="publisher" min="1" and step="1" required>
                      Quantity <input type="number" class='form-control' name="quantity" min="1" and step="1" required>
                            <br><input type="submit" class="btn btn-primary btn-sm">
                  </div>
              </form>
_END;
            
          $result->close();
          $conn->close();
          
          function get_post($conn, $var)
          {
            return $conn->real_escape_string($_POST[$var]);
          }
        ?>

    </div>
    </body>
</html>