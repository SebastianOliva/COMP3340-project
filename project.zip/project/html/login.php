<?php
    $hn = 'localhost'; //hostname
    $db = 'oliva1_project'; //database
    $un = 'oliva1_project'; //username
    $pw = 'mypassword'; //password
?>