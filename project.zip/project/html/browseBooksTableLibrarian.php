<?php
    $p_title = $_REQUEST['title'];
    require_once 'login.php';
    $conn = new mysqli($hn, $un, $pw, $db);
    if ($conn->connect_error)
        die($conn->connect_error);
            // get all books from DB ------------------------------
            $query  =  "SELECT
                        	b.Title,
                            a.Author,
                            b.ISBN,
                            c.Category,
                            concat(b.StockQuantity - (CASE WHEN bl.Unavailable IS NULL THEN 0 ELSE bl.Unavailable END), '/', b.StockQuantity) AS Stock,
                            b.StockQuantity - (CASE WHEN bl.Unavailable IS NULL THEN 0 ELSE bl.Unavailable END) As Available,
                            p.Publisher
                        FROM
                        	Books b
                            LEFT JOIN Authors a ON b.AuthorID = a.AuthorID
                            LEFT JOIN Category c ON b.CategoryID = c.CategoryID
                            LEFT JOIN (SELECT
                                       		ISBN,
                                       		COUNT(*) as Unavailable
                                       FROM
                                       		BookLending
                                       GROUP BY ISBN) bl ON b.ISBN = bl.ISBN
                            LEFT JOIN Publishers p on b.PublisherID = p.PublisherID
                        WHERE
                            b.Title LIKE '%$p_title%'
                        ORDER BY
                        	b.Title";
            $result = $conn->query($query);
            if (!$result)
              die ("Database access failed: " . $conn->error);
            $rows = $result->num_rows;
            // -------------------------------------------------------
        
            // print table of books -------------------------------
            echo <<<_END
                    <div class="table-responsive" id="searchBooksTable">
                        <table>
                            <thead>
                                  <tr>
                                    <th>Title</th>
                                    <th>Author</th>
                                    <th>ISBN</th>
                                    <th>Category</th>
                                    <th>Publisher</th>
                                    <th>Stock</th>
                                    <th></th>
                                  </tr>
                            </thead>
_END;

          for ($j = 0 ; $j < $rows ; ++$j)
          {
            $result->data_seek($j);
            $row = $result->fetch_array(MYSQLI_NUM);
        
            echo <<<_END
                            <tr>
                                <td class="titleColumn">$row[0]</td>
                                <td>$row[1]</td>
                                <td>$row[2]</td>
                                <td>$row[3]</td>
                                <td>$row[6]</td>
                                <td>$row[4]</td>
                                <td>
                                    <label for="button">
_END;
            if ($row[5] > 0) // check for book in stock
                echo "<button type='submit' name='isbn' value='$row[2]' class='btn btn-primary btn-sm'>Lend</button>";
            else
                echo "<button class='btn btn-secondary btn-sm' disabled>Lend</button>";
            echo <<<_END
                                    </label>
                                </td>
                            </tr>
_END;
            }
            echo <<<_END
                        </table>
                    </div>
_END;
        // -------------------------------------------------------
        
          $result->close();
          $conn->close();
?>