<html>
    <head>
        <title>UWindsor Library</title>
        <link rel="icon" type="image/png" href="../pictures/favicon.ico"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../css/table.css">
        <script src="../js/checkboxes.js"></script>
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <script src="../js/jquery-3.5.1.slim.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
    </head>
    <body class="text-center">
        <div class="container">
            <!-- TOP NAVIGATION -->
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
              <a class="navbar-brand unselectable">University of Windsor Library</a>
            </nav>
            <!-------------------->
            <!-- LOGIN FORM -->
            <div class="login-form">
                <form action="index.php" method="post">
                    <h2 class="text-center">Sign in</h2>       
                    <div class="form-group">
                        <input type="text" name="id" class="form-control" placeholder="UWinID" required="required">
                    </div>
                    <div class="form-group">
                        <input type="password" name="password" class="form-control" placeholder="Password" required="required">
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-block">Log in</button>
                    </div>
                </form>
            </div>
            <!-------------->
            
            <?php
                // CONNECT TO DB ----------------------------
                require_once 'login.php';
                $conn = new mysqli($hn, $un, $pw, $db);
                if ($conn->connect_error)
                    die($conn->connect_error);
                // ------------------------------------------
    
                session_start();
                
                // if user is already signed in, redirect to homepage ----------------------------------
                if (isset($_SESSION['username']))
                {
                    if ($_SESSION['clientTypeID'] == 1 || $_SESSION['clientTypeID'] == 2)
                    {
                        header("Location: bookSearch.php");
                    }
                    elseif ($_SESSION['clientTypeID'] == 3)
                    {
                        header("Location: bookSearchLibrarian.php");
                    }
                }
                // -------------------------------------------------------------------------------------
                
                if (isset($_POST['id']) && isset($_POST['password']))
                {
                    $id       = get_post($conn, 'id');
                    $password = hash('ripemd128', ('93rf' . $_POST['password'] . '8n$*')); // salt password before hash
                    $query    =    "SELECT
                                        c.ClientTypeID
                                    FROM
                                        Client c
                                    WHERE
                                        c.UniversityID = '$id' AND
                                        c.Password = '$password'";
                    $result   = $conn->query($query);
                    $rows     = $result->num_rows;
                    if (!$result)
                        die ("Database access failed: " . $conn->error);
                    $result->data_seek(0);
                    $row = $result->fetch_array(MYSQLI_NUM);
    
                    if ($rows==1)
                    {
                        session_unset();
                        $_SESSION['timeout'] = time() + 60 * 30; // if user doesn't change pages in 30 minutes, timeout
                        $_SESSION['username'] = $id;
                        $_SESSION['clientTypeID'] = $row[0];
                        if ($_SESSION['clientTypeID'] == 1 || $_SESSION['clientTypeID'] == 2)
                        {
                            header("Location: bookSearch.php");
                        }
                        elseif ($_SESSION['clientTypeID'] == 3)
                        {
                            header("Location: bookSearchLibrarian.php");
                        }
                    }
                    else
                    {
                        echo "<p class='text-danger'>Invalid Credentials</p>";
                    }
                }
                
                $result->close();
                $conn->close();
                  
                function get_post($conn, $var)
                {
                    return $conn->real_escape_string($_POST[$var]);
                }
            ?>
        
        </div>
    </body>
</html>