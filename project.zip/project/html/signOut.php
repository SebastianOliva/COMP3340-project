<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../css/table.css">
        <script src="../js/checkboxes.js"></script>
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <script src="../js/jquery-3.5.1.slim.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
    </head>
    <body>
        <?php
            // CONNECT TO DB ----------------------------
            require_once 'login.php';
            $conn = new mysqli($hn, $un, $pw, $db);
            if ($conn->connect_error)
                die($conn->connect_error);
            // ------------------------------------------
            // CANCEL SESSION ---------------------------
            session_start();
            session_unset();
            header("Location: index.php");
            // ------------------------------------------
        ?>
    </body>
</html>