<html>
    <head>
        <title>Profile</title>
        <link rel="icon" type="image/png" href="../pictures/favicon.ico"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../css/table.css">
        <script src="../js/checkboxes.js"></script>
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <script src="../js/jquery-3.5.1.slim.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="container">
            <!-- TOP NAVIGATION -->
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
              <a class="navbar-brand unselectable">University of Windsor Library</a>
              <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                  <a class="nav-item nav-link" href="bookSearch.php">Book Search<span class="sr-only">(current)</span></a>
                  <a class="nav-item nav-link" href="myBooks.php">My Books</a>
                  <a class="nav-item nav-link active" href="profile.php">Profile</a>
                  <a class="nav-item nav-link" href="signOut.php">Sign out</a>
                </div>
              </div>
            </nav>
            <!-- TOP NAVIGATION -->
            
            <br/>
            <h1 class="unselectable">Profile</h1>
            <br/>
            <?php
                // CONNECT TO DB ----------------------------
                require_once 'login.php';
                $conn = new mysqli($hn, $un, $pw, $db);
                if ($conn->connect_error)
                    die($conn->connect_error);
                // ------------------------------------------
                
                // CHECK SESSION -----------------------------------------------------------------------------------
                session_start();
                if (!isset($_SESSION['username']) || !isset($_SESSION['timeout']) || $_SESSION['timeout'] < time() || ($_SESSION['clientTypeID'] != 1 && $_SESSION['clientTypeID'] != 2))
                {
                    session_unset();
                    header("Location: index.php");
                }
                else
                {
                    $_SESSION['timeout'] = time() + 60 * 30;
                    $username = $_SESSION['username'];
                }
                // -------------------------------------------------------------------------------------------------
                
                // PAY WHEN USER CLICKS BUTTON ------------------
                if(isset($_POST['pay']))
                {
                    $query =   "UPDATE
                                	Client
                                SET
                                	OutstandingFees = 0
                                WHERE
                                	UniversityID = '$username'";
                    $result = $conn->query($query);
                    if (!$result)
                        die ("Database access failed: " . $conn->error);
                }
                // ----------------------------------------------
                
                function get_post($conn, $var)
                {
                    return $conn->real_escape_string($_POST[$var]);
                }
                
                // DISPLAY PROFILE ---------------------------------------------------------------------------------
                $query =    "SELECT
                            	FName,
                                LName,
                                OutstandingFees
                            FROM
                            	Client
                            WHERE UniversityID = '$username'";
                $result = $conn->query($query);
                if (!$result)
                    die ("Database access failed: " . $conn->error);
                $result->data_seek(0);
                $row = $result->fetch_array(MYSQLI_NUM);
                echo <<<_END
                    <div class="jumbotron">
                      <h2 class="display-4">$row[0] $row[1]</h2>
                      <p class="lead">$username@uwindsor.ca</p>
                      <hr class="my-4">
                      <p>Oustanding Fees: $
_END;
                echo number_format($row[2], 2);
                echo <<<_END
                      </p>
                      <p class="lead">
_END;
                if ($row[2] > 0)
                {
                    echo <<<_END
                    <form action="profile.php" method="post">
                        <input name="pay" class='btn btn-primary btn-lg' type="submit" value="Pay Now">
                    </form>
_END;
                }
                else
                    echo "<a class='btn btn-secondary btn-lg disabled' role='button'>Pay Now</a>";
                echo <<<_END
                      </p>
                    </div>
_END;
                // -------------------------------------------------------------------------------------------------
            
                $result->close();
                $conn->close();
            ?>
        </div>
    </body>
</html>