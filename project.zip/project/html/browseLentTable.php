<?php
    $clientID = $_REQUEST['clientID'];
    require_once 'login.php';
    $conn = new mysqli($hn, $un, $pw, $db);
    if ($conn->connect_error)
        die($conn->connect_error);
            // get lent books from DB ------------------------------
            $query  =   "SELECT
							bl.UniversityID,
                        	b.Title,
                            a.Author,
                            bl.ISBN,
                            c.Category,
                            CASE
                            	WHEN bl.DateLent IS NULL THEN 'N/A'
                                ELSE bl.DateLent
                            END,
                            CASE
                            	WHEN bl.DateDue IS NULL THEN 'N/A'
                                ELSE bl.DateDue
                            END,
                            CASE
                            	WHEN bl.IsReservation = 1 THEN 'Reserved'
                                WHEN bl.IsReservation = 0 THEN 'Lent'
                                ELSE ''
                            END,
                            bl.LendID
                        FROM
                        	BookLending bl
                            LEFT JOIN Books b on bl.ISBN = b.ISBN
                            LEFT JOIN Authors a on b.AuthorID = a.AuthorID
                            LEFT JOIN Category c ON b.CategoryID = c.CategoryID
                        WHERE
                            bl.UniversityID LIKE '%$clientID%'
                        ORDER BY bl.UniversityID";
            $result = $conn->query($query);
            if (!$result)
                die ("Database access failed: " . $conn->error);
             $rows = $result->num_rows;
        // -------------------------------------------------------
        
        // print table of books -------------------------------
            echo <<<_END
                <form method ="post" action="lentBooks.php">
                <div class="table-responsive" id="lentBooksTable">
                    <table>
                    <thead>
                          <tr>
                            <th>UWinID</th>
                            <th>Title</th>
                            <th>Author</th>
                            <th>ISBN</th>
                            <th>Category</th>
                            <th>Date Lent</th>
                            <th>Date Due</th>
                            <th>Status</th>
                            <th></th>
                          </tr>
                    </thead>
_END;

            if ($rows > 0)
            {
                for ($j = 0 ; $j < $rows ; ++$j)
                {
                    $result->data_seek($j);
                    $row = $result->fetch_array(MYSQLI_NUM);
            
                    echo <<<_END
                          <tr>
                            <td>$row[0]</td>
                            <td class="titleColumn">$row[1]</td>
                            <td>$row[2]</td>
                            <td>$row[3]</td>
                            <td>$row[4]</td>
                            <td>$row[5]</td>
                            <td>$row[6]</td>
                            <td>$row[7]</td>
                            <td>
_END;
                    if ($row[7] == 'Reserved')
                        echo "<label for='button'><button type='submit' name='cancelReservation' value='$row[8]' class='btn btn-primary btn-sm'>Cancel</button></label>";
                    else if ($row[7] == 'Lent')
                        echo "<label for='button'><button type='submit' name='returnBook' value='$row[8]' class='btn btn-primary btn-sm'>Return</button></label>";
                    echo <<<_END
                            </td>
                          </tr>
_END;
                }
            }
            else
            {
                echo <<<_END
                          <tr>
                            <td colspan="8" style="text-align:center;">There are no lent or reserved books that fit this search criteria.</td>
                          </tr>
_END;
            }

            echo <<<_END
            </table>
            </div>
            </form>
_END;
        // -------------------------------------------------------
    $result->close();
    $conn->close();
?>