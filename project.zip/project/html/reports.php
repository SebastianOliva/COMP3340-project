<html>
    <head>
        <title>Reports</title>
        <link rel="icon" type="image/png" href="../pictures/favicon.ico"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../css/table.css">
        <script src="../js/ajax.js"> </script>
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <script src="../js/jquery-3.5.1.slim.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript">
            google.charts.load('current', {'packages':['corechart']});
            
            // CATEGORY HISTORY --------------------------------------------------
            google.charts.setOnLoadCallback(drawCategoryHistory);
            function drawCategoryHistory() {
                var data = google.visualization.arrayToDataTable([
                    <?php
                        require_once 'login.php';
                        $conn = new mysqli($hn, $un, $pw, $db);
                        if ($conn->connect_error)
                            die($conn->connect_error);
                        $query  =  "SELECT
                                    	c.Category, COUNT(*)
                                    FROM
                                        (SELECT
                                         	ISBN
                                         FROM
                                         	LendingArchive
                                         UNION ALL
                                         SELECT
                                         	ISBN
                                         FROM
                                         	BookLending
                                         WHERE
                                        	IsReservation != 1) as ISBNs
                                         LEFT JOIN Books b ON ISBNs.ISBN = b.ISBN
                                         LEFT JOIN Category c ON b.CategoryID = c.CategoryID
                                    GROUP BY
                                    	c.Category";
                        $result = $conn->query($query);
                        if (!$result)
                            die ("Database access failed: " . $conn->error);
                        $rows = $result->num_rows;
                        echo "['Category', 'Number of Books'],";
                        for ($j = 0 ; $j < $rows ; ++$j)
                        {
                            $result->data_seek($j);
                            $row = $result->fetch_array(MYSQLI_NUM);
                            echo "['" . $row[0] . "'," . $row[1] . "],";
                        }
                    ?>
                ]);
                var options = { chartArea: { width: '94%' } };
                var chart = new google.visualization.PieChart(document.getElementById('categoryHistory'));
                chart.draw(data, options);
            }
            // MONTH HISTORY -------------------------------------------------
            google.charts.setOnLoadCallback(drawMonthHistory);
            function drawMonthHistory() {
                var data = google.visualization.arrayToDataTable([
                    <?php
                        require_once 'login.php';
                        $conn = new mysqli($hn, $un, $pw, $db);
                        if ($conn->connect_error)
                            die($conn->connect_error);
                        $query  =  "SELECT
                                    	m, COUNT(*)
                                    FROM
                                        (SELECT
                                         	MONTHNAME(DateLent) as m
                                         FROM
                                         	LendingArchive
                                         UNION ALL
                                         SELECT
                                         	MONTHNAME(DateLent) as m
                                         FROM
                                         	BookLending) as sub_table
                                    WHERE
                                    	m IS NOT NULL
                                    GROUP BY
                                    	m";
                        $result = $conn->query($query);
                        if (!$result)
                            die ("Database access failed: " . $conn->error);
                        $rows = $result->num_rows;
                        echo "['Category', 'Number of Books'],";
                        for ($j = 0 ; $j < $rows ; ++$j)
                        {
                            $result->data_seek($j);
                            $row = $result->fetch_array(MYSQLI_NUM);
                            echo "['" . $row[0] . "'," . $row[1] . "],";
                        }
                    ?>
                ]);
                var options = { chartArea: { width: '94%' } };
                var chart = new google.visualization.PieChart(document.getElementById('monthHistory'));
                chart.draw(data, options);
            }
            // AUTHOR HISTORY ------------------------------------------------
            google.charts.setOnLoadCallback(drawAuthorHistory);
            function drawAuthorHistory() {
                var data = google.visualization.arrayToDataTable([
                    <?php
                        require_once 'login.php';
                        $conn = new mysqli($hn, $un, $pw, $db);
                        if ($conn->connect_error)
                            die($conn->connect_error);
                        $query  =  "SELECT
                                    	a.Author, COUNT(*)
                                    FROM
                                        (SELECT
                                         	ISBN
                                         FROM
                                         	LendingArchive
                                         UNION ALL
                                         SELECT
                                         	ISBN
                                         FROM
                                         	BookLending
                                         WHERE
                                        	IsReservation != 1) as ISBNs
                                         LEFT JOIN Books b ON ISBNs.ISBN = b.ISBN
                                         LEFT JOIN Authors a ON b.AuthorID = a.AuthorID
                                    GROUP BY
                                    	a.Author";
                        $result = $conn->query($query);
                        if (!$result)
                            die ("Database access failed: " . $conn->error);
                        $rows = $result->num_rows;
                        echo "['Category', 'Number of Books'],";
                        for ($j = 0 ; $j < $rows ; ++$j)
                        {
                            $result->data_seek($j);
                            $row = $result->fetch_array(MYSQLI_NUM);
                            echo "['" . $row[0] . "'," . $row[1] . "],";
                        }
                    ?>
                ]);
                var options = { chartArea: { width: '94%' } };
                var chart = new google.visualization.PieChart(document.getElementById('authorHistory'));
                chart.draw(data, options);
            }
        </script>
    </head>
    <body>
        <div class="container">
            <!----------------- TOP NAVIGATION ------------------------>
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <a class="navbar-brand unselectable">University of Windsor Library</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                  <a class="nav-item nav-link" href="bookSearchLibrarian.php">Book Search</a>
                  <a class="nav-item nav-link" href="lentBooks.php">Lent Books</a>
                  <a class="nav-item nav-link" href="addBooks.php">Add Book</a>
                  <a class="nav-item nav-link active" href="reports.php">Reports<span class="sr-only">(current)</span></a>
                  <a class="nav-item nav-link" href="signOut.php">Sign Out</a>
                </div>
              </div>
            </nav>
            <!----------------- TOP NAVIGATION ----------------------->
            <br/>
            <h1 class="unselectable">Reports</h1>
            <?php
                // CONNECT TO DB ----------------------------
                require_once 'login.php';
                $conn = new mysqli($hn, $un, $pw, $db);
                if ($conn->connect_error)
                    die($conn->connect_error);
                // ------------------------------------------
                
                // CHECK SESSION -----------------------------------------------------------------------------------
                session_start();
                if (!isset($_SESSION['username']) || !isset($_SESSION['timeout']) || $_SESSION['timeout'] < time() || $_SESSION['clientTypeID'] != 3)
                {
                    session_unset();
                    header("Location: index.php");
                }
                else
                {
                    $_SESSION['timeout'] = time() + 60 * 30;
                    $username = $_SESSION['username'];
                }
                // -------------------------------------------------------------------------------------------------
            ?>
            <br><br>
            <div id="categoryHistory" style=" height: 50%;"></div>
            <p>Historical percentage of books lent by category.<hr class='my-4'></p>
            <div id="monthHistory" style=" height: 50%;"></div>
            <p>Historical percentage of books lent by month lent.<hr class='my-4'></p>
            <div id="authorHistory" style=" height: 50%;"></div>
            <p>Historical percentage of books lent by author.<hr class='my-4'></p>
        </div>
    </body>
</html>