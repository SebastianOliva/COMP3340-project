<html>
    <head>
        <title>Book Search</title>
        <link rel="icon" type="image/png" href="../pictures/favicon.ico"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../css/table.css">
        <script src="../js/ajax.js"> </script>
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <script src="../js/jquery-3.5.1.slim.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="container">
        <!----------------- TOP NAVIGATION ------------------------>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <a class="navbar-brand unselectable">University of Windsor Library</a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
              <a class="nav-item nav-link active" href="bookSearch.php">Book Search<span class="sr-only">(current)</span></a>
              <a class="nav-item nav-link" href="myBooks.php">My Books</a>
              <a class="nav-item nav-link" href="profile.php">Profile</a>
              <a class="nav-item nav-link" href="signOut.php">Sign out</a>
            </div>
          </div>
        </nav>
        <!----------------- TOP NAVIGATION ----------------------->
        
        <br/>
        <h1 class="unselectable">Book Search</h1>
        <br/>
        <?php
            // CONNECT TO DB ----------------------------
            require_once 'login.php';
            $conn = new mysqli($hn, $un, $pw, $db);
            if ($conn->connect_error)
                die($conn->connect_error);
            // ------------------------------------------
            
            // CHECK SESSION -----------------------------------------------------------------------------------
            session_start();
            if (!isset($_SESSION['username']) || !isset($_SESSION['timeout']) || $_SESSION['timeout'] < time() || ($_SESSION['clientTypeID'] != 1 && $_SESSION['clientTypeID'] != 2))
            {
                session_unset();
                header("Location: index.php");
            }
            else
            {
                $_SESSION['timeout'] = time() + 60 * 30;
                $username = $_SESSION['username'];
            }
            // -------------------------------------------------------------------------------------------------

            // RESERVE BOOK --------------------------------------
            if (isset($_POST['isbn']))
            {
                $isbn = $_POST['isbn'];
                $fail = false;
                
                // check for outstanding fees
                $query  =  "SELECT
                            	OutStandingFees
                            FROM
                            	Client
                            WHERE
                            	Client.UniversityID = '$username'";
                $result = $conn->query($query);
                if (!$result)
                  die ("Database access failed: " . $conn->error);
                $result->data_seek(0);
                $row = $result->fetch_array(MYSQLI_NUM);
                if ($row[0] > 0)
                {
                    echo "You cannot reserve a book because you have outstanding fees on your account. Pay these fees in the Profile tab before reserving a book.<br><br><hr class='my-4'><br><br>";
                    $fail = true;
                }
                
                // check for too many books
                $query  =  "SELECT
                            	COUNT(*)
                            FROM
                                BookLending
                            WHERE
                            	UniversityID = '$username'";
                $result = $conn->query($query);
                if (!$result)
                  die ("Database access failed: " . $conn->error);
                $result->data_seek(0);
                $row = $result->fetch_array(MYSQLI_NUM);
                if ($row[0] >= 2)
                {
                    echo "You cannot reserve or lend more than two books at once.<br><br><hr class='my-4'><br><br>";
                    $fail = true;
                }
                
                // check out more than one of the same book
                $query  =  "SELECT
                                COUNT(*)
                            FROM
                            	BookLending
                            WHERE ISBN = $isbn AND UniversityID = '$username'";
                $result = $conn->query($query);
                if (!$result)
                  die ("Database access failed: " . $conn->error);
                $result->data_seek(0);
                $row = $result->fetch_array(MYSQLI_NUM);
                if ($row[0] >= 1)
                {
                    echo "You cannot reserve or lend more than one of the same book.<br><br><hr class='my-4'><br><br>";
                    $fail = true;
                }
                
                // reserve book if no fails
                if (!$fail)
                {
                    $query  = "INSERT INTO BookLending (ISBN, IsReservation, UniversityID) VALUES ($isbn, 1, '$username')";
                    $result = $conn->query($query);
                    if (!$result)
                      die ("Database access failed: " . $conn->error);
                    echo "Book successfully reserved.<br><br><hr class='my-4'><br><br>";
                }
            }
            // ---------------------------------------------------

            // get all books from DB ------------------------------
            $query  =  "SELECT
                        	b.Title,
                            a.Author,
                            b.ISBN,
                            c.Category,
                            concat(b.StockQuantity - (CASE WHEN bl.Unavailable IS NULL THEN 0 ELSE bl.Unavailable END), '/', b.StockQuantity) AS Stock,
                            b.StockQuantity - (CASE WHEN bl.Unavailable IS NULL THEN 0 ELSE bl.Unavailable END) As Available,
                            p.Publisher
                        FROM
                        	Books b
                            LEFT JOIN Authors a ON b.AuthorID = a.AuthorID
                            LEFT JOIN Category c ON b.CategoryID = c.CategoryID
                            LEFT JOIN (SELECT
                                       		ISBN,
                                       		COUNT(*) as Unavailable
                                       FROM
                                       		BookLending
                                       GROUP BY ISBN) bl ON b.ISBN = bl.ISBN
                            LEFT JOIN Publishers p on b.PublisherID = p.PublisherID
                        ORDER BY
                        	b.Title";
            $result = $conn->query($query);
            if (!$result)
              die ("Database access failed: " . $conn->error);
            $rows = $result->num_rows;
            // -------------------------------------------------------
        
            // print table of books -------------------------------
            echo <<<_END
            
                <form name='ajax' onsubmit='return false;'>
                    <div class="md-form mt-0">
                        Search Title: <input name='title' class='form-control' id='title' type='text' onkeyup='searchtitle();'>
                    </div>
                </form>
                
                <form method ="post" action="bookSearch.php">
                    <div class="table-responsive" id="searchBooksTable">
                        <table>
                            <thead>
                                  <tr>
                                    <th>Title</th>
                                    <th>Author</th>
                                    <th>ISBN</th>
                                    <th>Category</th>
                                    <th>Publisher</th>
                                    <th>Stock</th>
                                    <th></th>
                                  </tr>
                            </thead>
_END;

          for ($j = 0 ; $j < $rows ; ++$j)
          {
            $result->data_seek($j);
            $row = $result->fetch_array(MYSQLI_NUM);
        
            echo <<<_END
                            <tr>
                                <td class="titleColumn">$row[0]</td>
                                <td>$row[1]</td>
                                <td>$row[2]</td>
                                <td>$row[3]</td>
                                <td>$row[6]</td>
                                <td>$row[4]</td>
                                <td>
                                    <label for="button">
_END;
            if ($row[5] > 0)
                echo "<button type='submit' name='isbn' value='$row[2]' class='btn btn-primary btn-sm'>Reserve</button>";
            else
                echo "<button class='btn btn-secondary btn-sm' disabled>Reserve</button>";
            echo <<<_END
                                    </label>
                                </td>
                            </tr>
_END;
            }
            echo <<<_END
                        </table>
                    </div>
                </form>
_END;
        // -------------------------------------------------------
        
          $result->close();
          $conn->close();

          function get_post($conn, $var)
          {
            return $conn->real_escape_string($_POST[$var]);
          }
        ?>

    </div>
    </body>
</html>