function searchtitle(){
    var title = document.getElementById('title').value;
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var msg = this.responseText;
            document.getElementById("searchBooksTable").innerHTML = msg;
        }
    };
    xmlhttp.open("GET", "browseBooksTable.php?title=" + title, true);
    xmlhttp.send();
}

function searchTitleLibrarian(){
    var title = document.getElementById('title').value;
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var msg = this.responseText;
            document.getElementById("searchBooksTable").innerHTML = msg;
        }
    };
    xmlhttp.open("GET", "browseBooksTableLibrarian.php?title=" + title, true);
    xmlhttp.send();
}

function searchClientID(){
    var title = document.getElementById('clientID').value;
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var msg = this.responseText;
            document.getElementById("lentBooksTable").innerHTML = msg;
        }
    };
    xmlhttp.open("GET", "browseLentTable.php?clientID=" + title, true);
    xmlhttp.send();
}